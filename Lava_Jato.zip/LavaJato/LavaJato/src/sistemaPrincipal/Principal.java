package sistemaPrincipal;

import estrutura_geral.Cliente;
import estrutura_geral.Veiculo;
import  estrutura_geral.Servico;
import  estrutura_geral.Venda;

import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
      Scanner sc = new Scanner(System.in);

      System.out.println("--- Cadastro do Cliente ---");
      System.out.println("Digite o nome do cliente: ");
      String nomeCliente = sc.nextLine();

      System.out.println("Digite o telefone do cliente: ");
      String telefoneCliente = sc.nextLine();

      System.out.println("Digite o Email do cliente: ");
      String emailCliente = sc.nextLine();

      Cliente cliente = new Cliente(nomeCliente,telefoneCliente,emailCliente);

      System.out.println("\n--- Cadastro do Veiculo ---");
      System.out.println("Digite a placa do veículo: ");
      String placa = sc.nextLine();

      System.out.println("Digite o modelo do veículo: ");
      String modelo = sc.nextLine();

      System.out.println("Digite a marca do veículo: ");
      String marca = sc.nextLine();

      System.out.println("Digite o ano do veículo: ");
      int ano = sc.nextInt();

      System.out.println("Digite a cor do veículo: ");
      String cor = sc.nextLine();


      System.out.println("Digite o nome do dono do veículo: ");
      String dono = sc.nextLine();

      System.out.println("\n--- Serviços Disponíveis ---");
      boolean continuar = true;
      while (continuar) {
          System.out.println("\nDigite a descrição do serviço: ");
          String descricao = sc.nextLine();

        System.out.print("Digite o preço do serviço: ");
        double preco = sc.nextDouble();
        sc.nextLine();

        Servico servico = new Servico(descricao, preco);

        System.out.print("\nDeseja adicionar outro serviço? (s/n): ");
        String resposta = sc.nextLine();

        if (!resposta.equalsIgnoreCase("s")) {
          continuar = false;
        }
      }
    }
}