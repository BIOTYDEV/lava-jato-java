package estrutura_geral;

public class Nota {

}
