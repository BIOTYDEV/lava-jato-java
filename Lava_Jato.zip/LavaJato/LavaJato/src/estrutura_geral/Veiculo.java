package estrutura_geral;

public class Veiculo {
    private String modelo;
    private String marca;
    private String placa;
    private int ano;
    private String cor;
    private Cliente dono;

    public Veiculo(String modelo, String marca, String placa,
                   int ano, String cor, Cliente dono) {
        this.modelo = modelo;
        this.marca = marca;
        this.placa = placa;
        this.ano = ano;
        this.cor = cor;
        this.dono = dono;
    }

    public String getModelo(){return modelo;}
    public String getMarca(){return marca;}
    public String getPlaca(){return placa;}
    public int getAno(){return ano;}
    public String getCor(){return cor;}
    public Cliente getDono(){return dono;}

}
