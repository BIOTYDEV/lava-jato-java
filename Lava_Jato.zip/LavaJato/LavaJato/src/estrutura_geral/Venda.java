package estrutura_geral;

import java.util.ArrayList;
import java.util.List;

public class Venda {
    private Veiculo veiculo;
    private List<Servico> servicos = new ArrayList<>();

        public Venda(Veiculo veiculo) {
            this.veiculo = veiculo;
    }

    public void adicionarServico(Servico servico) {
            servicos.add(servico);
    }

    public double calculoTotal() {
            return servicos.stream()
                    .mapToDouble(Servico::getPreco)
                    .sum();
    }

    public Veiculo getVeiculo(){
            return veiculo;
    }

    public List<Servico> getServicos() {
            return servicos;
    }
}
