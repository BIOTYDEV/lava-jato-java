package nota;

import estrutura_geral.Servico;
import estrutura_geral.Venda;

public class NotaFiscal {
    private Venda venda;

    public NotaFiscal(Venda venda) {
        this.venda = venda;
    }

    public void gerarNota() {
        System.out.println("\n--- Nota Fiscal ---");
        System.out.println("Cliente: " + venda.getVeiculo().getDono().getNome());
        System.out.println("Veículo: " + venda.getVeiculo().getModelo() + " - " + venda.getVeiculo().getPlaca());
        System.out.println("Serviços realizados:");

        for (Servico s : venda.getServicos()) {
            System.out.println(" - " + s.getDescricao() + ": R$" + s.getPreco());
        }
        System.out.println("Total: R$" + venda.calculoTotal());
        System.out.println("-----------------------\n");
    }
}
